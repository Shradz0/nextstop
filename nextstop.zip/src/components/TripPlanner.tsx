import React, { useState } from 'react';
import { generateItinerary, TripPlan } from '../lib/gemini';
import { VIBES, BUDGETS, PACES } from '../constants';
import { cn } from '../lib/utils';
import { MapPin, Calendar, Compass, Loader2 } from 'lucide-react';

interface TripPlannerProps {
  onGenerationComplete: (trip: TripPlan) => void;
}

export function TripPlanner({ onGenerationComplete }: TripPlannerProps) {
  const [destination, setDestination] = useState('');
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [vibe, setVibe] = useState(VIBES[0].id);
  const [budget, setBudget] = useState(BUDGETS[1].id);
  const [pace, setPace] = useState(PACES[1].id);
  const [loading, setLoading] = useState(false);

  const popularDestinations = [
    'Paris, France', 'Tokyo, Japan', 'New York City, USA', 'London, UK', 
    'Rome, Italy', 'Bali, Indonesia', 'Dubai, UAE', 'Barcelona, Spain',
    'Amsterdam, Netherlands', 'Singapore', 'Seoul, South Korea', 'Bangkok, Thailand',
    'Mumbai, India', 'New Delhi, India', 'Goa, India', 'Jaipur, India', 'India'
  ];

  const handleDestinationChange = (val: string) => {
    setDestination(val);
    if (val.length > 1) {
      const filtered = popularDestinations.filter(d => 
        d.toLowerCase().includes(val.toLowerCase())
      );
      setSuggestions(filtered);
      setShowSuggestions(true);
    } else {
      setSuggestions([]);
      setShowSuggestions(false);
    }
  };

  const selectSuggestion = (s: string) => {
    setDestination(s);
    setSuggestions([]);
    setShowSuggestions(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!destination || !startDate || !endDate) return;

    setLoading(true);
    try {
      const trip = await generateItinerary(destination, startDate, endDate, { vibe, budget, pace });
      onGenerationComplete(trip);
    } catch (error) {
      console.error("Failed to generate trip:", error);
      alert("Something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white border border-slate-200 rounded-[32px] p-6 md:p-10 shadow-xl shadow-slate-100 relative overflow-hidden">
      {/* Decorative Brand Accent */}
      <div className="absolute top-0 right-0 w-32 h-32 bg-blue-50/50 rounded-bl-full -mr-10 -mt-10" />
      
      <form onSubmit={handleSubmit} className="relative z-10 space-y-12">
        <div className="grid md:grid-cols-3 gap-8">
          <div className="md:col-span-1 space-y-3">
            <label className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-600 ml-1">Destination Focus</label>
            <div className="relative group">
              <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-300 group-focus-within:text-blue-500 transition-colors" />
              <input 
                type="text" 
                placeholder="Search destination..."
                value={destination}
                onChange={(e) => handleDestinationChange(e.target.value)}
                onFocus={() => destination.length > 1 && setShowSuggestions(true)}
                className="w-full bg-slate-50 border border-slate-200 rounded-2xl py-4 pl-12 pr-4 outline-none focus:border-blue-500 focus:bg-white transition-all text-sm font-bold placeholder:text-slate-500 shadow-inner"
              />
              {showSuggestions && suggestions.length > 0 && (
                <div className="absolute top-full left-0 right-0 mt-2 bg-white border border-slate-200 rounded-2xl shadow-xl z-50 overflow-hidden">
                  {suggestions.map((s) => (
                    <button
                      key={s}
                      type="button"
                      onClick={() => selectSuggestion(s)}
                      className="w-full px-4 py-3 text-left text-sm font-bold text-slate-600 hover:bg-blue-50 hover:text-blue-600 transition-colors border-b border-slate-50 last:border-0"
                    >
                      {s}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          <div className="space-y-3">
            <label className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-600 ml-1">Start Date</label>
            <div className="relative group">
              <Calendar className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-300 group-focus-within:text-blue-500 transition-colors" />
              <input 
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-2xl py-4 pl-12 pr-4 outline-none focus:border-blue-500 focus:bg-white transition-all text-sm font-bold shadow-inner"
              />
            </div>
          </div>

          <div className="space-y-3">
            <label className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-600 ml-1">End Date</label>
            <div className="relative group">
              <Calendar className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-300 group-focus-within:text-blue-500 transition-colors" />
              <input 
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-2xl py-4 pl-12 pr-4 outline-none focus:border-blue-500 focus:bg-white transition-all text-sm font-bold shadow-inner"
              />
            </div>
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-12">
          <section className="space-y-5">
            <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-600 border-b border-slate-100 pb-3">Travel Vibe</h4>
            <div className="grid grid-cols-2 gap-2.5">
              {VIBES.map((v) => (
                <button
                  key={v.id}
                  type="button"
                  onClick={() => setVibe(v.id)}
                  className={cn(
                    "px-3 py-2.5 rounded-xl border text-[10px] font-black uppercase tracking-wider transition-all text-center",
                    vibe === v.id 
                      ? "bg-blue-600 border-blue-700 text-white shadow-lg shadow-blue-100" 
                      : "bg-white border-slate-200 text-slate-600 hover:border-slate-300 hover:bg-slate-50"
                  )}
                >
                  {v.label}
                </button>
              ))}
            </div>
          </section>

          <section className="space-y-5">
            <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-600 border-b border-slate-100 pb-3">Security & Budget</h4>
            <div className="space-y-2.5">
              {BUDGETS.map((b) => (
                <button
                  key={b.id}
                  type="button"
                  onClick={() => setBudget(b.id)}
                  className={cn(
                    "w-full px-4 py-3 rounded-xl border text-[10px] font-black uppercase tracking-widest transition-all flex justify-between items-center",
                    budget === b.id 
                      ? "bg-slate-900 border-slate-950 text-white shadow-lg shadow-slate-200" 
                      : "bg-white border-slate-200 text-slate-600 hover:border-slate-300"
                  )}
                >
                  <span>{b.label}</span>
                  {budget === b.id && <div className="w-2 h-2 rounded-full bg-blue-500 shadow-[0_0_8px_rgba(59,130,246,0.6)]" />}
                </button>
              ))}
            </div>
          </section>

          <section className="space-y-5">
            <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-600 border-b border-slate-100 pb-3">Temporal Logic</h4>
            <div className="space-y-2.5">
              {PACES.map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => setPace(p.id)}
                  className={cn(
                    "w-full px-4 py-3 rounded-xl border text-[10px] font-black uppercase tracking-widest transition-all flex justify-between items-center",
                    pace === p.id 
                      ? "bg-slate-900 border-slate-950 text-white shadow-lg shadow-slate-200" 
                      : "bg-white border-slate-200 text-slate-600 hover:border-slate-300"
                  )}
                >
                  <span>{p.label}</span>
                  {pace === p.id && <div className="w-2 h-2 rounded-full bg-blue-500 shadow-[0_0_8px_rgba(59,130,246,0.6)]" />}
                </button>
              ))}
            </div>
          </section>
        </div>

        <div className="pt-8 border-t border-slate-100 flex justify-center md:justify-end">
          <button
            disabled={loading || !destination || !startDate || !endDate}
            className="w-full md:w-auto px-12 py-4 bg-blue-600 text-white font-black uppercase tracking-[0.25em] text-[11px] rounded-2xl hover:bg-blue-700 hover:scale-[1.02] transition-all disabled:opacity-50 disabled:scale-100 shadow-xl shadow-blue-200 flex items-center justify-center gap-3"
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Planning Journey...
              </>
            ) : (
              <>
                Plan Journey
                <Compass className="w-4 h-4" />
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
}
