import React, { useState } from 'react';
import { TripPlan, adaptItinerary } from '../lib/gemini';
import { motion, AnimatePresence } from 'motion/react';
import { Clock, Sparkles, RefreshCw, ChevronRight, Share2, MoreHorizontal, AlertCircle } from 'lucide-react';
import { cn } from '../lib/utils';

interface ItineraryViewProps {
  trip: TripPlan;
  onUpdate: (trip: TripPlan) => void;
}

export function ItineraryView({ trip, onUpdate }: ItineraryViewProps) {
  const [adapting, setAdapting] = useState(false);
  const [updateText, setUpdateText] = useState('');
  const [showAdaptModal, setShowAdaptModal] = useState(false);

  const handleAdapt = async () => {
    if (!updateText) return;
    setAdapting(true);
    try {
      const updatedTrip = await adaptItinerary(trip, updateText);
      onUpdate(updatedTrip);
      setUpdateText('');
      setShowAdaptModal(false);
    } catch (error) {
      console.error("Adaptation failed:", error);
      alert("Failed to adapt itinerary. Try a different request.");
    } finally {
      setAdapting(false);
    }
  };

  const [activeDay, setActiveDay] = useState(1);

  return (
    <div className="space-y-10">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
        <div className="flex gap-2 overflow-x-auto pb-1 sm:pb-0 w-full sm:w-auto scrollbar-hide">
          {trip.days.map((day) => (
             <button 
              key={day.dayNumber}
              onClick={() => setActiveDay(day.dayNumber)}
              className={cn(
                "px-4 py-2 rounded-md border text-xs font-bold shadow-sm transition-all whitespace-nowrap",
                activeDay === day.dayNumber 
                  ? "bg-blue-600 border-blue-700 text-white shadow-lg shadow-blue-100" 
                  : "bg-white border-slate-200 text-slate-800 hover:bg-slate-50"
              )}
            >
              Day {day.dayNumber}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-3 w-full sm:w-auto">
          <button 
            onClick={() => setShowAdaptModal(true)}
            className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-4 py-2 bg-white border border-slate-200 rounded-md text-xs font-bold text-slate-800 shadow-sm hover:bg-slate-50 transition-all"
          >
            <Sparkles className="w-4 h-4 text-blue-500" />
            Tune Logic
          </button>
          <button 
            onClick={() => {
              if (trip) {
                navigator.share?.({
                  title: `Trip to ${trip.destination}`,
                  text: `Check out my itinerary for ${trip.destination}!`,
                  url: window.location.href
                }).catch(() => alert("Sharing not supported on this browser"));
              }
            }}
            className="p-2 bg-white border border-slate-200 rounded-md text-slate-600 hover:text-slate-800"
          >
            <Share2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="space-y-0">
        {trip.days
          .filter(day => day.dayNumber === activeDay)
          .flatMap(day => day.activities.map((activity, aIdx) => (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            key={`${day.dayNumber}-${aIdx}`} 
            className="flex gap-4 sm:gap-6 group"
          >
            {/* Timeline Column */}
            <div className="flex flex-col items-center shrink-0 w-10 sm:w-12">
              <div className="text-[10px] font-bold text-slate-600 py-1">{activity.time}</div>
              <div className="w-px flex-1 bg-slate-200 my-1 group-last:bg-transparent"></div>
            </div>

            {/* Content Card */}
            <div className="flex-1 pb-8">
              <div className="bg-white border border-slate-200 p-4 sm:p-5 rounded-2xl shadow-sm hover:border-blue-300 transition-all flex flex-col sm:flex-row sm:items-center justify-between relative group/card gap-4">
                <div className="flex items-start sm:items-center gap-4 sm:gap-5">
                   <div className="shrink-0">
                    {activity.imageSearchQuery ? (
                      <img 
                        src={`https://loremflickr.com/320/240/${encodeURIComponent(activity.imageSearchQuery)}`} 
                        alt={activity.placeName}
                        className="w-16 h-16 sm:w-20 sm:h-20 rounded-xl object-cover border border-slate-100 shadow-sm grayscale group-hover/card:grayscale-0 transition-all"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <div className="w-16 h-16 sm:w-20 sm:h-20 bg-slate-50 rounded-xl border border-slate-100 flex items-center justify-center text-xl grayscale group-hover/card:grayscale-0 transition-all">
                        {activity.category.toLowerCase().includes('food') ? '🍱' : 
                         activity.category.toLowerCase().includes('sight') ? '🏛️' : 
                         activity.category.toLowerCase().includes('travel') ? '🚆' : '📍'}
                      </div>
                    )}
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-slate-800">{activity.placeName}</h4>
                    <p className="text-[10px] sm:text-xs text-slate-600 font-medium">
                      {activity.category} • {activity.estimatedCost || 'N/A'}
                    </p>
                    <p className="text-xs text-slate-500 mt-2 leading-relaxed max-w-xl line-clamp-2 sm:line-clamp-none">{activity.description}</p>
                  </div>
                </div>
                
                <div className="text-right flex flex-row sm:flex-col items-center sm:items-end justify-between sm:justify-center gap-3">
                   <div className="flex items-center gap-1 text-[10px] bg-blue-50 border border-blue-100 px-2 py-1 rounded font-bold text-blue-600 uppercase tracking-tighter">
                    <Clock className="w-3 h-3" /> Sync Active
                  </div>
                  <ChevronRight className="hidden sm:block w-4 h-4 text-slate-200 group-hover/card:text-blue-500 transition-colors" />
                </div>
              </div>
              
              {/* Distance/Transition Logic (Simulated) */}
              {aIdx < day.activities.length - 1 && (
                <div className="ml-4 sm:ml-6 py-4 flex items-center gap-2 text-slate-500">
                  <div className="w-1 h-1 rounded-full bg-slate-200" />
                  <span className="text-[10px] font-bold uppercase tracking-widest italic">15m Transition via Local Infrastructure</span>
                </div>
              )}
            </div>
          </motion.div>
        )))}
      </div>

      {/* Adaptation Modal */}
      <AnimatePresence>
        {showAdaptModal && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center p-8 bg-slate-900/40 backdrop-blur-sm"
          >
            <motion.div 
              initial={{ scale: 0.95, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 20 }}
              className="w-full max-w-lg bg-white border border-slate-200 rounded-3xl p-8 shadow-2xl space-y-6"
            >
              <div className="space-y-1">
                <div className="flex items-center gap-2 text-blue-600">
                  <Sparkles className="w-5 h-5" />
                  <span className="text-[10px] font-black uppercase tracking-widest">Intelligent Engine</span>
                </div>
                <h3 className="text-2xl font-black tracking-tight text-slate-900">What do we need to adapt?</h3>
                <p className="text-sm text-slate-600 font-medium">Input constraints or preference shifts for NextStop to process.</p>
              </div>

              <textarea 
                value={updateText}
                onChange={(e) => setUpdateText(e.target.value)}
                placeholder="e.g. Flight delay in Tokyo, or we want a more relaxed pace tomorrow."
                className="w-full bg-slate-50 border border-slate-200 rounded-xl p-4 min-h-[140px] outline-none focus:border-blue-500 focus:bg-white transition-all text-sm resize-none font-medium placeholder:text-slate-500"
              />

              <div className="flex justify-end gap-3 pt-4 border-t border-slate-100">
                <button 
                  onClick={() => setShowAdaptModal(false)}
                  className="px-6 py-2 text-[10px] font-black uppercase tracking-widest text-slate-600 hover:text-slate-800 transition-colors"
                >
                  Discard
                </button>
                <button 
                  disabled={adapting || !updateText}
                  onClick={handleAdapt}
                  className="px-8 py-3 bg-blue-600 text-white rounded-lg text-[10px] font-black uppercase tracking-widest disabled:opacity-50 flex items-center gap-2 hover:bg-blue-700 shadow-lg shadow-blue-100 transition-all"
                >
                  {adapting ? <RefreshCw className="w-3 h-3 animate-spin" /> : <Sparkles className="w-3 h-3" />}
                  {adapting ? "Processing..." : "Commit Update"}
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
