# NextStop Security Specification

## Data Invariants
1. A user can only read and write their own profile (`/users/{userId}`).
2. A trip can only be read or written by the user who created it (`userId` field in the trip document).
3. Timestamps (`createdAt`, `updatedAt`) must be server-generated.
4. Itineraries must follow a strict schema to prevent junk data injection.

## The Dirty Dozen Payloads
1. **Identity Spoofing**: Attempt to create a user profile with a different `uid` than the authenticated user.
2. **Unauthorized Read**: Authenticated User A tries to read User B's trip.
3. **Privilege Escalation**: Attempt to set an `isAdmin` field (though not explicitly in schema, rules should block it).
4. **Orphaned Trip**: Create a trip for a `userId` that doesn't exist.
5. **Path Poisoning**: Inject a 1MB string as a `tripId`.
6. **Schema Violation**: Create a trip without any `days`.
7. **Timestamp Fraud**: Provide a client-side `createdAt` date in the past.
8. **Shadow Update**: Update a trip with an extra "isVerified: true" field.
9. **Outcome Locking**: Attempt to modify the `destination` of a trip after it's been created (immutability).
10. **Resource Exhaustion**: Send a trip with 10,000 activities in a single day.
11. **Email Verification Bypass**: Access private profile data with an unverified email (if mandated).
12. **Query Scraping**: List all trips without filtering by `userId`.

## Test Runner (Draft)
A comprehensive test suite will ensure these payloads are rejected.
